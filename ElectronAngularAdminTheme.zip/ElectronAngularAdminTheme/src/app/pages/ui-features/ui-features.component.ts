import { Component } from '@angular/core';

@Component({
  selector: 'ngx-ui-features',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class UiFeaturesComponent {
}
