import { Component, OnInit } from '@angular/core';
import {ElectronService} from '../core/services';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor(
    public electronService: ElectronService,
  ) {

  }

  ngOnInit() {
  }

  clickMe() {
    const notification = {
      title: 'Basic Notification',
      body: 'This is an Electron notification'
    }
    const myNotification =  new Notification(notification.title, notification);
    console.log(myNotification);
  }

}
